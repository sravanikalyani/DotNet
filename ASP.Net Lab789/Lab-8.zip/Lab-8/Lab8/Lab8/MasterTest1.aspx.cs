﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab8
{
    public partial class MasterTest1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MyMaster1 m = (MyMaster1)this.Master;
            m.PageHeading = "A New Page Heading by Child Content Page";

        }

        protected void btnMultiply_Click(object sender, EventArgs e)
        {
            try
            {
                int res = int.Parse(TextBox1.Text) * int.Parse(TextBox2.Text);
                Label3.Text = res.ToString();
            }
            catch (Exception ex)
            {
                Label3.Text = ex.Message;
            }
        }
    }
}