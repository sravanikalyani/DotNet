﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Entity;

namespace HMS.Exception
{
    /// <summary>
    /// Id : 161619
    /// Author: JAndhyala Sravana Kalyani
    /// DoC:17th Oct
    /// Desc: Exception class defined with Exception Handling
    /// </summary>
    public class PatientException : ApplicationException
    {
        public PatientException():base()
        {

        }

        public PatientException(string errMessage):base(errMessage)
        {

        }
    }
}
