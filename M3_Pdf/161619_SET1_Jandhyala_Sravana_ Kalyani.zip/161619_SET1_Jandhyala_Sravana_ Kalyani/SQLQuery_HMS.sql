use Sep19CHN

create table SK.PatientDetails
(
PID int identity(10,1) primary key,
DateAndTime datetime,
PFirstName varchar(20),
PLastName varchar(20),
PGender char,
PAddress varchar(50),
PCity varchar(20),
PState varchar(20),
PinCode int,
PContact bigint,
)

drop table SK.PatientDetails


insert into SK.PatientDetails values('10/17/2018','kalyani','sravani','m',623,'talangana','hyderabad',502319, 7036544684) 
insert into SK.PatientDetails values('10/17/2018','kalyani','sravani','m',623,'talangana','maharastra',502319, 7036544684) 
insert into SK.PatientDetails values('10/17/2018','kalyani','sravani','m',623,'talangana','hyderabad',502319, 7036544684) 
insert into SK.PatientDetails values('10/17/2018','kalyani','sravani','m',623,'talangana','Maharastra',502319, 7036544684) 
insert into SK.PatientDetails values('10/17/2018','kalyani','sravani','m',623,'talangana','Pune',502319, 7036544684) 

select * from SK.PatientDetails

CREATE proc SK.usp_AddPatient
@eName varchar(20),
@eLoc varchar(20),
@ePh bigint,
@eDeptId int
As
BEGIN
insert into SK.PatientDetails values(@eName,@eLoc,@ePh,@eDeptId)
END