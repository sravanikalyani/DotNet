﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo1
{
    public interface IPrintable
    {
        void Show();
        void Print();
    }
}
